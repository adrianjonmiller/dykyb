@layout( 'templates.layouts.sidebar' )
{{-- Template Name: Sidebar

@section('page-content')

	@include('templates.content.page')

@endsection