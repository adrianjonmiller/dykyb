@layout('templates.layouts.normal')

@section('page-content')

  @include('templates.content.index')
  
@endsection