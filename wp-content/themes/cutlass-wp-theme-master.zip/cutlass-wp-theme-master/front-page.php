@layout( 'templates.layouts.normal' )

@section('page-content')

	@include('templates.content.front-page')

@endsection