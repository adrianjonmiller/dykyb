<header class="page-header">
  <h1>
    {{ cutlass_title() }}
  </h1>
</header>
