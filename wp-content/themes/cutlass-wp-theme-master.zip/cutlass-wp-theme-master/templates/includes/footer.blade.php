<footer class="content-info" role="contentinfo">
  <div class="container">
    {{ dynamic_sidebar('sidebar-footer') }}
  </div>
</footer>
