@layout('templates.layouts.base')

@section('content')
	<main class="main" role="main">
		@yield('page-content')
	</main><!-- /.main -->
@endsection