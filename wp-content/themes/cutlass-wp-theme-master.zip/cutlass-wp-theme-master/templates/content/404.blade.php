@include('templates.includes.page-header')

<h1>Sorry there doesn't appear to be content here!</h1>
<p>Try searching for what you're looking for:</p>
{{ get_search_form() }}