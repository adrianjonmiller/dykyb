@layout( 'templates.layouts.normal' )

@section('page-content')

	@include('templates.content.single')

@endsection