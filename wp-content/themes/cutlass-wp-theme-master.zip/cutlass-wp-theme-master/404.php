@layout( 'templates.layouts.normal' )

@section('page-content')

	@include('templates.content.404')

@endsection