This section of the theme borrows heavily from the Blade plugin for Wordpress made by Mikael Mattsson. There are aspects that I (Zach Adams) have changed to better suite this theme, however the original credit for this code goes to Mikael.

You can find the Github for the original plugin [here](https://github.com/MikaelMattsson/blade)